'user strict'

var express = require('express');
var userController = require('../controllers/user.controller');
var api = express.Router();



api.post('/Registro', userController.Registro);
api.post('/login', userController.login);

//Clases
api.put('/:id/setClase', userController.setClase);
api.get('/:id/getClases', userController.getClases);
api.put('/:idU/updateClase/:idC', userController.updateClase);
api.put('/:idU/removeClase/:idC', userController.removeClase);

//Alumno
api.put('/updateAlumno/:id',userController.updateAlumno);
api.delete('/removeAlumno/:id', userController.removeAlumno);



module.exports = api;