'user strict'

var User = require('../models/user.model');
var bcrypt = require('bcrypt-nodejs');
var Clase = require('../models/clases.model');
var Alumno = require('../models/alunmo.model');
const use  = require('../routes/user.route');


function createInit(req,res){
    let user = new User();
    user.username = 'admin'
    user.password = '12345'
    user.save((err, userSaved)=>{
        if(err){
            console.log('Error al crear el usuario');
        }else if(userSaved){
            console.log('Usuario administrador creado');
        }else{
            console.log('Usuario administrador no creado');
        }
    })
}


function login(req, res){
    var params = req.body;

    if(params.username && params.password){
        User.findOne({username: params.username}, (err, userFind)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor al intentar buscar'})
            }else if(userFind){
                bcrypt.compare(params.password, userFind.password, (err, checkPassword)=>{
                    if(err){
                        res.status(500).send({message: 'Error general en el servidor'});
                    }else if(checkPassword){
                        res.status(200).send({message: 'Usuario logeado exitosamente'});
                    }else{
                        res.status(404).send({message: 'Nombre de usuario o contraseña incorrectas'})
                    }
                })
            }else{
                res.status(200).send({message: 'No se encontró la cuenta'})
            }
        })
    }else{
        res.status(200).send({message: 'Por favor ingresa todos los campos'})
    }
}

function Registro(req, res){
    var user = new User();
    var params = req.body;

    if(params.name && params.lastname && params.username && params.password && params.email && params.phone){
        User.findOne({username:params.username},(err, userFind)=>{
            if(err){
                res.status(500).send({message: 'Error general', err})
            }else if(userFind){
                res.status(200).send({message: 'Usuario ya existente'})
            }else{
                bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                    if(err){
                        res.status(500).send({message:'Error en la incriptacion'})
                    }else if (passwordHash){

                        user.password = passwordHash
                        user.name = params.name;
                        user.lastname = params.lastname;
                        user.username = params.username;
                        user.password = params.password
                        user.email = params.email;
                        user.phone = params.phone;
                        
                        user.save((err,userSaved)=>{
                            if(err){
                                res.status(500).send({message:'Error al guardar los datos'})
                            }else if(userSaved){
                                res.status(200).send({message: 'Ususario guardado'})
                            }
                         })
                    }
                })
            }
        })
    }else{
        res.status(200).send({message:'Ingresar todos los datos'})
    }
}






//CREAR,EDITAR,ELIMINAR y VISUALIZAR 


function setClase(req, res){
    let userId = req.params.id;
    let paramsClases = req.body;
    let clase = new clase();

    User.findById(userId, (err, userFind)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor al intentar agregar un contacto'});
        }else if(userFind){
            if(paramsClases.name ){
                clase.name = paramsClases.name;
                User.findByIdAndUpdate(userId, {$push:{clases: clase}}, {new: true}, (err, userUpdated)=>{
                    if(err){
                        res.status(500).send({message: 'Error general en el servidor'});
                    }else if(userUpdated){
                        res.status(200).send({message: 'Clase agregada', userUpdated})
                    }else{
                        res.status(404).send({message: 'Clase no agregado'});
                    }
                })
            }else{
                res.status(200).send({message: 'Ingrese los datos mínimos para agregar un Clase'})
            }
        }else{
            res.status(200).send({message: 'No existe el usuario'});
        }
    });
}

function getClases(req, res){
    let userId = req.params.id;

    User.findOne({_id: userId}).exec((err, userClass)=>{
        if(err){
            res.status(500).send({message: 'Error general en el servidor'});
        }else if(userContact){
            res.status(200).send({message: 'Clases: ', clases: userClass.clases})
        }else{
            res.status(404).send({message: 'Clase no agregado'});
        }
    })
}

function updateClase(req, res){
    let userId = req.params.idU;
    let claseId = req.params.idC;
    let update = req.body;

    if(update.name){
        User.findOne({_id: userId}, (err, userFind)=>{
            if(err){
                res.status(500).send({message: 'Error general'});
            }else if(userFind){
                User.findOneAndUpdate({_id: userId, 'clases._id': claseId}, 
                {'contacts.$.name': update.name}, {new:true}, (err, userUpdated)=>{
                    if(err){
                        res.status(500).send({message: 'Error general al actualizar doc. embedido'});
                    }else if(userUpdated){
                        res.status(200).send({message: 'Clases actualizadas: ', userUpdated});
                    }else{
                        res.status(404).send({message: 'Clase no actualizado'});
                    }
                })
            }else{
                res.status(200).send({message: 'Usuario inexistente'});
            }
        });
    }else{
        res.status(200).send({message: 'Envía los datos mínimos'});
    } 
}

function removeClase(req, res){
    let userId = req.params.idU;
    let claseId = req.params.idC;

    User.findOneAndUpdate({_id: userId, 'clases._id': claseId},
    {$pull:{clases:{_id: claseId}}}, {new: true}, (err, classRemove)=>{
        if(err){
            res.status(500).send({message: 'Error general al eliminar documento embedido'});
        }else if(classRemove){
            res.status(200).send({message: 'Clase fue eliminado: ', classRemove});
        }else{
            res.status(404).send({message: 'Clase no encontrado o ya eliminado'});
        }
    })

}



//ALUMNO 
function updateAlumno(req, res){
    let userId = req.params.id;
    let update = req.body;

    if(update.username){
        Alumno.findOne({username: update.username}, (err, usernameFind)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor'});
            }else if(usernameFind){
                res.status(200).send({message: 'Nombre de alumno ya existente, no se puede actualizar su cuenta'});
            }else{
                Alumno.findByIdAndUpdate(userId, update, {new: true} ,(err, userUpdated)=>{
                    if(err){
                        res.status(500).send({message: 'Error en el servidor al intentar actualizar'});
                    }else if(userUpdated){
                        res.status(200).send({message: 'alumno actualizado', userUpdated});
                    }else{
                        res.status(200).send({message: 'No hay registros para actualizar'});
                    }
                });
            }
        })


    }else{
        Alumno.findByIdAndUpdate(userId, update, {new: true} , (err, userUpdated)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor al intentar actualizar'});
            }else if(userUpdated){
                res.status(200).send({message: 'alumno actualizado', userUpdated});
            }else{
                res.status(200).send({message: 'No hay registros para actualizar'});
            }
        });
    }

}


function removeAlumno(req, res){
    let userId = req.params.id;

    Alumno.findByIdAndRemove(userId, (err, userRemoved)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor al intentar eliminar el registro'});
        }else if(userRemoved){
            res.status(200).send({message: 'Alumno eliminado', userRemoved});
        }else{
            res.status(200).send({message: 'No existe el alumno, o ya fue eliminado'});
        }
    })
}



 


module.exports = {
    //USER
    createInit,
    Registro,
    login,
    //CLASES
    setClase,
    getClases,
    updateClase,
    removeClase,
    //ALUMNO
     updateAlumno,
     removeAlumno,
}
